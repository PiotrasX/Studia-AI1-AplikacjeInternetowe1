<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateTripRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        $tripId = $this->route('trip');
        return [
            'name' => 'required|string|max:50',
            'continent' => 'required|string|max:255',
            'period' => 'required|integer|min:1',
            'description' => 'required|string|max:65535',
            'price' => 'required|numeric|min:0',
            'img' => 'sometimes|string|max:255',
            'country_id' => 'required|exists:countries,id'
        ];
    }
}

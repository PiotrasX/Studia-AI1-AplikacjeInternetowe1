<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use App\Http\Middleware\LogActivity;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__ . '/../routes/web.php',
        commands: __DIR__ . '/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
        $middleware->web(LogActivity::class);
    })
    ->withExceptions(function (Exceptions $exceptions) {

        $exceptions->report(function (Exception $e) {
            Log::channel('lab9_errors')->error($e->getMessage());
        });

        $exceptions->render(function (QueryException $e, Request $request) {
            $errorCode = $e->errorInfo[1];
            if ($errorCode == '1451') {
                return back()->withError(__('Cannot delete record'));
            } else {
                return back()->withError(print_r($e->errorInfo, true))->withInput();
            }
        });
    })->create();
